package com.mvc.board.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Board1 {

		private int rnum;
		
		private int No;
		
		private int write_No;
		
		private String ceoName;
		
		private String campName;
		
		private String address;
		
		private String phone;
		
		private String env;
		
		private String type;
		
		private String operating_Season;
		
		private String operating_Days;
		
		private String hompage;
		
		private String reserv;
		
		private String about;

	
		
		

}
